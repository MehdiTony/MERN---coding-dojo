// // GIVEN
// console.log(example);
// var example = "I'm the example!";
// // AFTER HOISTING BY THE INTERPRETER
// // var example;
// // console.log(example); // logs undefined
// // example = "I'm the example!";

// First example


// --------First Example-------------------
var hello = 'world';
console.log(hello);

//undefined

// ------Second example-------------------

// Global variable declaration
var needle = 'haystack';
// Function call
test();
// Function declaration
function test() {
    // Local variable declaration
    var needle = 'magnet';
    console.log(needle);
}

// Output: magnet

//------Third example-------------------

// Global variable declaration
var brendan = 'super cool';

// Function declaration
function print() {
    // Value assignment to global variable
    brendan = 'only okay';
    // Console logging the value of the global variable
    console.log(brendan);
}

// Console logging the value of the global variable
console.log(brendan);

// Output : super cool



//-----Fourth example----------------------

var food = 'chicken';
console.log(food);
eat();
function eat() {
    food = 'half-chicken';
    console.log(food);
    var food = 'gone';
}

//Output : chicken
//Output : Half-chicken 

//--------Fifth example----------------------


mean();
console.log(food);
var mean = function () {
    food = "chicken";
    console.log(food);
    var food = "fish";
    console.log(food);
}
console.log(food);

// Output : Refferenceerror mean is not a function

//----------Sixth example-------------------------------------

console.log(genre);
var genre = "disco";
rewind();
function rewind() {
    genre = "rock";
    console.log(genre);
    var genre = "r&b";
    console.log(genre);
}
console.log(genre);


//Output : Undefined 
//Output : rock
//Output : r&b
//Output: disco

//----------Seventh Example----------------------------

dojo = "san jose";
console.log(dojo);
learn();
function learn() {
    dojo = "seattle";
    console.log(dojo);
    var dojo = "burbank";
    console.log(dojo);
}
console.log(dojo);


//Output : san jose
//Output : seattle
//Output : burbank
//Output : san jose


//-----------Eigth Example--------------------------------------


console.log(makeDojo("Chicago", 65));
console.log(makeDojo("Berkeley", 0));
function makeDojo(name, students) {
    const dojo = {};
    dojo.name = name;
    dojo.students = students;
    if (dojo.students > 50) {
        dojo.hiring = true;
    }
    else if (dojo.students <= 0) {
        dojo = "closed for now";
    }
    return dojo;
}


//Output : {name: 'Chicago', students: 65, hiring: true}
//Output : TypeError 




