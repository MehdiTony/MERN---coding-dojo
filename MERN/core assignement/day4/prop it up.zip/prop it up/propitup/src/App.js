import logo from './logo.svg';
import './App.css';
import PersonCard from './PersonCard';


const people = [
  { firstName: 'John', lastName: 'Doe', age: 25, hairColor: 'black' },
  { firstName: 'Jane', lastName: 'Doe', age: 30, hairColor: 'brown' },
  { firstName: 'Bob', lastName: 'Smith', age: 40, hairColor: 'blonde' },
  { firstName: 'Alice', lastName: 'Johnson', age: 35, hairColor: 'red' }
];

function render() {
  return (
    <div>
      {people.map(person => (
        <PersonCard
          firstName={person.firstName}
          lastName={person.lastName}
          age={person.age}
          hairColor={person.hairColor}
        />
      ))}
    </div>
  );
}
export default App;
